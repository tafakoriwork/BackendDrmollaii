<?php

namespace App\Http\Controllers\units;

use App\Http\Controllers\Controller;
use App\Models\Flashcard;
use App\Models\FreeFlashcard;
use App\Models\User;
use Illuminate\Http\Request;

class FreeFlashcardController extends Controller
{
    public function index(Request $request)
    {
        $api_token = $request->bearerToken();
        $user = User::where(['api_token' => $api_token])->first();
        return FreeFlashcard::where('user_id', $user->id)->get();
    }

    public function ids(Request $request)
    {
        return Flashcard::where('freeflashcardscategory_id', $request->id)->get()->pluck('id');
    }

    public function store(Request $request)
    {
        $api_token = $request->bearerToken();
        $user = User::where(['api_token' => $api_token])->first();
        return FreeFlashcard::create([
            'user_id' => $user->id,
            'title' => $request->title,
        ]);
    }

    public function delete($id)
    {
        return FreeFlashcard::destroy($id);
    }
}
